import { useRef } from "react";
import { useInView } from "framer-motion";

interface ScrollRevealOptions {
  once?: boolean;
  margin?: `${number}px` | `${number}px ${number}px` | `${number}px ${number}px ${number}px ${number}px`;
  amount?: number;
}

export function useScrollReveal(options: ScrollRevealOptions = {}) {
  const { once = true, margin = "-50px", amount = 0.15 } = options;
  const ref = useRef<HTMLElement>(null);
  const isInView = useInView(ref, { once, margin, amount });

  const revealStyles = {
    opacity: isInView ? 1 : 0,
    transform: isInView ? "translateY(0)" : "translateY(40px)",
    transition: "opacity 0.8s cubic-bezier(0.22, 1, 0.36, 1), transform 0.8s cubic-bezier(0.22, 1, 0.36, 1)",
  };

  return { ref, isInView, revealStyles };
}
