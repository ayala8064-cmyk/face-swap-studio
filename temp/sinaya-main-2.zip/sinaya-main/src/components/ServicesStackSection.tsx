import { useRef, useEffect, useState } from "react";
import AnimatedText from "./AnimatedText";
import matureWigs from "@/assets/services/mature-wigs.webp";
import medicalWigs from "@/assets/services/medical-wigs.webp";
import bridalEvents from "@/assets/services/bridal-events.webp";
import wigRepairs from "@/assets/services/wig-repairs.webp";
import salonServices from "@/assets/services/salon-services.webp";
import consultations from "@/assets/services/consultations.webp";

const services = [
  {
    id: "mature",
    title: "Mature Wigs",
    description: "Celebrate your style at every age. These wigs are thoughtfully designed to suit mature faces, flattering features and creating a graceful, effortless elegance that feels authentically you.",
    image: matureWigs,
    bgColor: "#323232"
  },
  {
    id: "medical",
    title: "Medical Wigs",
    description: "Regain your confidence with wigs that feel as natural as your own hair. Crafted for comfort and style, each piece is a gentle reminder that beauty and self-assurance can thrive at every stage.",
    image: medicalWigs,
    bgColor: "#414141"
  },
  {
    id: "bridal",
    title: "Bridal & Events",
    description: "Step into your special moment with elegance designed just for you. From flowing waves to polished updos, every hairstyle enhances your beauty and captures the spirit of the occasion.",
    image: bridalEvents,
    bgColor: "#494949"
  },
  {
    id: "repairs",
    title: "Wig Repairs",
    description: "Give your wig new life. With meticulous attention and expert care, every repair or upgrade restores its natural beauty, ensuring it continues to move, shine, and impress.",
    image: wigRepairs,
    bgColor: "#565656"
  },
  {
    id: "salon",
    title: "Salon Services",
    description: "From precision cuts to rich color, smoothing treatments to professional styling, every service is tailored to your hair type and personality. The result is hair that looks stunning and feels healthy, always.",
    image: salonServices,
    bgColor: "#686868"
  },
  {
    id: "consultations",
    title: "Consultations",
    description: "A moment to explore, discover, and decide. With expert guidance, every choice—wig, style, or color—is made with confidence, ensuring the final look reflects the best version of you.",
    image: consultations,
    bgColor: "#767575"
  }
];

const ServicesStackSection = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      if (!containerRef.current) return;
      
      const rect = containerRef.current.getBoundingClientRect();
      const windowHeight = window.innerHeight;
      const containerHeight = containerRef.current.offsetHeight;
      
      const scrollStart = rect.top;
      const scrollRange = containerHeight - windowHeight;
      
      if (scrollStart > 0) {
        setScrollProgress(0);
      } else if (-scrollStart >= scrollRange) {
        setScrollProgress(1);
      } else {
        setScrollProgress(-scrollStart / scrollRange);
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const bannerHeight = 550;
  const overlapAmount = bannerHeight / 3;
  const visiblePortion = bannerHeight - overlapAmount;

  const getBannerTransform = (index: number) => {
    const numBanners = services.length;
    const progressPerBanner = 1 / numBanners;
    const bannerProgress = scrollProgress / progressPerBanner - index;
    
    const finalY = index * visiblePortion;
    
    if (bannerProgress < 0) {
      return `translateY(100vh)`;
    } else if (bannerProgress >= 1) {
      return `translateY(0px)`;
    } else {
      const yOffset = (1 - bannerProgress) * 100;
      return `translateY(${yOffset}vh)`;
    }
  };

  const totalStackHeight = bannerHeight + (services.length - 1) * overlapAmount;

  return (
    <section 
      ref={containerRef}
      className="relative bg-[#282828]"
      style={{ 
        height: `${100 + services.length * 100}vh`
      }}
    >
      <div className="sticky top-0 h-screen overflow-hidden flex flex-col justify-end">
        <div className="relative w-full" style={{ height: `${totalStackHeight}px` }}>
          {services.map((service, index) => (
            <div
              key={service.id}
              className="absolute left-0 right-0 transition-transform duration-700 ease-out"
              style={{
                height: `${bannerHeight}px`,
                bottom: `${(services.length - 1 - index) * overlapAmount}px`,
                backgroundColor: service.bgColor,
                transform: getBannerTransform(index),
                zIndex: index + 1
              }}
            >
              <div className="h-full px-8 md:px-16 lg:px-24 flex items-center">
                <div className="flex items-center gap-16 max-w-[1200px] mx-auto w-full">
                  <div className="flex-shrink-0">
                    <img
                      src={service.image}
                      alt={service.title}
                      className="w-[280px] h-[350px] object-cover rounded-lg"
                    />
                  </div>
                  
                  <div className="flex flex-col gap-4">
                    <AnimatedText
                      as="h3"
                      className="font-light"
                      style={{
                        fontSize: '48px',
                        color: '#C8A89C',
                        letterSpacing: '0.01em'
                      }}
                    >
                      {service.title}
                    </AnimatedText>
                    <AnimatedText
                      as="p"
                      className="font-light max-w-[400px]"
                      style={{
                        fontSize: '16px',
                        lineHeight: '1.6',
                        color: 'rgba(200, 168, 156, 0.7)'
                      }}
                      delay={0.2}
                    >
                      {service.description}
                    </AnimatedText>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesStackSection;
