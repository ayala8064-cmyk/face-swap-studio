import { useLayoutEffect, useRef, useState } from "react";
import gsap from "gsap";
import sinaya1 from "@/assets/collection/sinaya-1.jpg";
import sinaya2 from "@/assets/collection/sinaya-2.jpg";
import sinaya3 from "@/assets/collection/sinaya-3.jpg";
import sinaya4 from "@/assets/collection/sinaya-4.jpg";

/**
 * Radial / Elliptical Testimonials Carousel
 * - Images move ONLY on an elliptical arc (GSAP)
 * - 3 visible positions: LEFT / CENTER / RIGHT + hidden recycler
 * - Infinite loop, symmetric forward/backward
 * - NO drag
 * - Background fully transparent
 * - Testimonial text is in a SEPARATE static layer (not rotated)
 * - Text changes on arrow click with FADE animation only
 */

type Item = { id: string; src: string };

type Testimonial = {
  title: string;
  body: string;
  author: string;
};

const items: Item[] = [
  { id: "img1", src: sinaya1 },
  { id: "img2", src: sinaya2 },
  { id: "img3", src: sinaya3 },
  { id: "img4", src: sinaya4 },
];

const testimonials: Testimonial[] = [
  {
    title: "Beyond Expectations",
    body: "From the consultation to the final fitting, the experience felt thoughtful and refined. Every detail was considered.",
    author: "— Linda Cohen",
  },
  {
    title: "Seamless Process",
    body: "Everything was clear and easy from start to finish. Communication was excellent and the result was exactly what I wanted.",
    author: "— Sarah Levi",
  },
  {
    title: "Beautiful Craftsmanship",
    body: "The quality is outstanding. It feels premium, looks perfect, and the finishing touches are on another level.",
    author: "— Miriam Adler",
  },
  {
    title: "Highly Recommended",
    body: "A calm, professional experience with beautiful results. I would absolutely recommend this again.",
    author: "— Rachel Stein",
  },
];

const mod = (n: number, m: number) => ((n % m) + m) % m;

export default function ReviewsSection() {
  const stageRef = useRef<HTMLDivElement | null>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);
  const shiftRef = useRef(0);

  const [centerIndex, setCenterIndex] = useState(0);
  const textRef = useRef<HTMLDivElement | null>(null);

  const geomRef = useRef({ RX: 0, RY: 0, centerY: 0, off: 0 });

  // -------- Geometry & poses --------

  const getPose = (slot: number) => {
    const { RX, RY, centerY, off } = geomRef.current;

    if (slot === 0) return { x: -RX, y: centerY, scale: 0.7, rotate: 10, zIndex: 2 };
    if (slot === 1) return { x: 0, y: centerY + RY, scale: 1, rotate: -10, zIndex: 10 };
    if (slot === 2) return { x: RX, y: centerY, scale: 0.7, rotate: -10, zIndex: 2 };
    return { x: RX + off, y: centerY, scale: 0.7, rotate: -10, zIndex: 0 };
  };

  const setPositions = () => {
    cardsRef.current.forEach((el, i) => {
      const slot = mod(i + shiftRef.current, items.length);
      gsap.set(el, getPose(slot));
    });
  };

  // -------- Animation step --------

  const step = (dir: 1 | -1) => {
    const prev = shiftRef.current;
    const next = prev + dir;

    gsap.killTweensOf(cardsRef.current);

    const tl = gsap.timeline({ defaults: { duration: 1, ease: "power4.inOut" } });

    cardsRef.current.forEach((el, i) => {
      const fromSlot = mod(i + prev, items.length);
      const toSlot = mod(i + next, items.length);

      const { RX, centerY, off } = geomRef.current;

      if (dir === 1 && fromSlot === 2 && toSlot === 3) {
        tl.to(el, { x: RX + off, y: centerY, scale: 0.7, rotate: -10, zIndex: 0 }, 0);
        return;
      }

      if (dir === 1 && fromSlot === 3 && toSlot === 0) {
        tl.set(el, { x: -RX - off, y: centerY, scale: 0.7, rotate: 10, zIndex: 0 }, 0);
        tl.to(el, getPose(0), 0);
        return;
      }

      if (dir === -1 && fromSlot === 0 && toSlot === 3) {
        tl.to(el, { x: -RX - off, y: centerY, scale: 0.7, rotate: 10, zIndex: 0 }, 0);
        return;
      }

      if (dir === -1 && fromSlot === 3 && toSlot === 2) {
        tl.set(el, { x: RX + off, y: centerY, scale: 0.7, rotate: -10, zIndex: 0 }, 0);
        tl.to(el, getPose(2), 0);
        return;
      }

      tl.to(el, getPose(toSlot), 0);
    });

    shiftRef.current = next;
    setCenterIndex(mod(1 - next, items.length));
  };

  // -------- Text fade --------

  useLayoutEffect(() => {
    if (!textRef.current) return;

    gsap.fromTo(
      textRef.current,
      { opacity: 0 },
      { opacity: 1, duration: 0.4, ease: "power2.out" }
    );
  }, [centerIndex]);

  // -------- Init & resize --------

  useLayoutEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;

    const compute = () => {
      const w = stage.clientWidth;
      const h = stage.clientHeight;
      const cardW = w * 0.2;

      geomRef.current = {
        RX: Math.round(w / 2 - cardW * 0.6),
        RY: Math.round((w / 2 - cardW * 0.6) / 5),
        centerY: Math.round(h * 0.05),
        off: w,
      };

      setPositions();
      setCenterIndex(mod(1 - shiftRef.current, items.length));
    };

    compute();
    window.addEventListener("resize", compute);
    return () => window.removeEventListener("resize", compute);
  }, []);

  const t = testimonials[centerIndex];

  // ---------------- Render ----------------

  return (
    <section className="w-screen h-screen relative overflow-hidden bg-transparent">
      <div ref={stageRef} className="absolute inset-0">
        {/* Images */}
        <div className="absolute inset-0 flex items-center justify-center">
          {items.map((item, i) => (
            <div
              key={item.id}
              ref={(el) => (cardsRef.current[i] = el!)}
              className="absolute"
            >
              <div className="w-[20vw] h-[50vh] rounded-2xl overflow-hidden bg-white">
                <img src={item.src} className="w-full h-full object-cover" alt="" />
              </div>
            </div>
          ))}
        </div>

        {/* Testimonial text – STATIC layer */}
        <div
          ref={textRef}
          className="absolute left-1/2 top-1/2 -translate-y-1/2 ml-[12vw] max-w-[420px]"
        >
          <h3 className="text-[22px] text-[#282828] font-display font-normal">{t.title}</h3>
          <p className="mt-3 text-[14px] leading-[1.8] text-[#5a5a5a]">{t.body}</p>
          <p className="mt-4 text-[16px] text-[#282828]">{t.author}</p>
        </div>

        {/* Arrows */}
        <button
          onClick={() => step(-1)}
          className="absolute left-[30vw] bottom-[20vh] text-black text-3xl z-50"
        >
          ←
        </button>
        <button
          onClick={() => step(1)}
          className="absolute left-[34vw] bottom-[20vh] text-black text-3xl z-50"
        >
          →
        </button>
      </div>
    </section>
  );
}
