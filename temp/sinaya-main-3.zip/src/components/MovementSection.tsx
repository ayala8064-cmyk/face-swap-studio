import movementImage from "@/assets/movement-section-image.webp";
import movementIcon from "@/assets/movement-icon.webp";

const MovementSection = () => {
  return (
    <section className="w-full h-screen flex">
      {/* Left Side - Text Content */}
      <div className="w-1/2 bg-white flex flex-col items-center px-16 pt-[8%]">
        {/* Icon */}
        <div className="mb-10">
          <img src={movementIcon} alt="Movement icon" className="w-12 h-10 object-contain" />
        </div>
        
        {/* Thin Horizontal Line */}
        <div className="w-full max-w-[420px] h-px bg-[#d4d4d4] mb-[72px]"></div>
        
        {/* Two-line Headline */}
        <h2 
          className="text-[42px] font-display font-light text-center leading-[1.3] tracking-wide"
          style={{ color: '#282828' }}
        >
          Natural movement that
          <br />
          flows like real hair
        </h2>
      </div>

      {/* Right Side - Image with Floating Card */}
      <div className="w-1/2 relative">
        <img src={movementImage} alt="Woman with flowing hair" className="w-full h-full object-cover" />
        
        {/* Floating "Movement" Card */}
        <div 
          className="absolute top-[48%] -translate-y-1/2 left-0 -translate-x-1/2 bg-[#F3F4F6] rounded-2xl flex items-center justify-center"
          style={{ width: '280px', height: '260px' }}
        >
          <span 
            className="text-[52px] font-display font-light"
            style={{ color: '#282828' }}
          >
            Movement
          </span>
        </div>
      </div>
    </section>
  );
};

export default MovementSection;
