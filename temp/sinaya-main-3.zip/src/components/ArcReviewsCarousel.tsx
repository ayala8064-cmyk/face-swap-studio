import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import AnimatedText from "./AnimatedText";

// Import local images
import batel from "@/assets/collection/batel.webp";
import devora from "@/assets/collection/devora.jpeg";
import penina from "@/assets/collection/penina.jpeg";
import sinaya4 from "@/assets/collection/sinaya-4.jpg";
import sinaya5 from "@/assets/collection/sinaya-5.jpg";

// Import arrow icons
import arrowLeft from "@/assets/arrow-left.svg";
import arrowRight from "@/assets/arrow-right.svg";
import reviewsCurve from "@/assets/reviews-curve.svg";
type Review = {
  id: string;
  imageUrl: string;
  title: string;
  body: string;
  author: string;
};
const DEFAULT_REVIEWS: Review[] = [{
  id: "r1",
  imageUrl: batel,
  title: "Exceptional quality and precision",
  body: "I have two wigs from Sinaya and I'm extremely happy with them. The hair quality is excellent, and the color precision is on another level. Especially with lighter shades — anyone who understands wigs knows how difficult it is to achieve a light color that doesn't look orange or artificial, and Sinaya does it perfectly. The wigs look very natural, last for many years, and I receive so many compliments. I wholeheartedly recommend her.",
  author: "Satisfied Client"
}, {
  id: "r2",
  imageUrl: devora,
  title: "Truly one of a kind",
  body: "I have been a client of Sinya's for 19 years, and I can say with complete confidence — she is truly one of a kind. Her wigs are simply exceptional: the hair is soft and pleasant to the touch, the wig itself is lightweight and comfortable to wear, and the final result is absolutely stunning. Every time I step out wearing one of her wigs, I receive countless compliments and am constantly asked where I bought it. Beyond the outstanding quality of her work, Sinya has truly gifted hands and a remarkably generous heart.",
  author: "Longtime Client (19 years)"
}, {
  id: "r3",
  imageUrl: penina,
  title: "There is truly no one like Sinya",
  body: "There is truly no one like Sinya. She is highly professional and has a remarkable ability to understand what suits each client, knowing exactly how to tailor a wig or hairstyle to the individual woman. In addition, Sinya is pleasant, trustworthy, and a genuine pleasure to work with. Sinya is the first to offer kindness and compassion through her business. I have referred women undergoing oncology treatments to her, and Sinya immediately puts everything in place to help.",
  author: "Grateful Client"
}];
function getArcPosition(offset: number) {
  const x = offset * 280;
  const y = Math.pow(offset, 2) * 35;
  const rotation = offset * 8;
  const scale = 1.05 - Math.abs(offset) * 0.12;
  const opacity = Math.abs(offset) <= 2 ? 1 - Math.abs(offset) * 0.3 : 0;
  const zIndex = 10 - Math.abs(offset);
  return {
    x,
    y,
    rotation,
    scale,
    opacity,
    zIndex
  };
}
function getShortestOffset(index: number, activeIndex: number, total: number): number {
  const directOffset = index - activeIndex;
  const wrapForward = directOffset + total;
  const wrapBackward = directOffset - total;
  const offsets = [directOffset, wrapForward, wrapBackward];
  return offsets.reduce((shortest, current) => Math.abs(current) < Math.abs(shortest) ? current : shortest);
}
export default function ArcReviewsCarousel({
  reviews = DEFAULT_REVIEWS
}: {
  reviews?: Review[];
}) {
  const [activeIndex, setActiveIndex] = useState(0);
  const goNext = () => {
    setActiveIndex(current => (current + 1) % reviews.length);
  };
  const goPrev = () => {
    setActiveIndex(current => (current - 1 + reviews.length) % reviews.length);
  };
  const activeReview = reviews[activeIndex];
  return <section className="w-full h-screen bg-[#F2EEEA] overflow-hidden relative">
      {/* Arc curve that follows the images carousel path */}
      <svg className="absolute left-1/2 top-1/2 pointer-events-none" style={{
      transform: 'translate(-50%, -50%) translateX(100px) translateY(80px)',
      width: '1400px',
      height: '300px'
    }} viewBox="0 0 1400 300" fill="none">
        <path d="M 0 150 Q 350 280, 700 280 Q 1050 280, 1400 150" stroke="#C9C9C9" strokeWidth="1" fill="none" />
      </svg>

      {/* Title - moved up */}
      <AnimatedText as="h2" className="absolute left-16 top-[20%] font-display text-[#282828]" style={{
      fontSize: '170px',
      lineHeight: '1',
      writingMode: 'horizontal-tb'
    }}>
        Reviews
      </AnimatedText>

      {/* Images container */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative w-[1100px] h-[520px]" style={{
        marginLeft: '200px'
      }}>
          <div className="absolute left-1/2 top-1/2 w-full h-full">
            {reviews.map((review, index) => {
            const offset = getShortestOffset(index, activeIndex, reviews.length);
            const position = getArcPosition(offset);
            const isVisible = Math.abs(offset) <= 2;
            return <motion.div key={review.id} className="absolute" style={{
              left: '50%',
              top: '50%',
              zIndex: position.zIndex
            }} animate={{
              x: position.x,
              y: position.y,
              rotate: position.rotation,
              scale: position.scale,
              opacity: isVisible ? position.opacity : 0
            }} transition={{
              type: "spring",
              stiffness: 80,
              damping: 22,
              mass: 1
            }}>
                  <div className="-translate-x-1/2 -translate-y-1/2" style={{
                transform: 'translate(-50%, -50%) rotate(-8deg)'
              }}>
                    <div className="rounded-[18px] bg-white/70 p-[6px] shadow-sm">
                      <img src={review.imageUrl} alt={review.title} className="w-[260px] h-[310px] object-cover rounded-[14px]" draggable={false} />
                    </div>
                  </div>
                </motion.div>;
          })}
          </div>
        </div>
      </div>

      {/* Review text */}
      <div className="absolute top-1/2 -translate-y-1/2" style={{
      left: 'calc(50% + 320px)',
      width: '420px'
    }}>
        <AnimatePresence mode="wait">
          <motion.div key={activeReview.id} initial={{
          opacity: 0,
          y: 10
        }} animate={{
          opacity: 1,
          y: 0
        }} exit={{
          opacity: 0,
          y: -10
        }} transition={{
          duration: 0.4,
          ease: "easeOut"
        }}>
            <h3 className="text-[22px] text-[#282828] font-display font-normal">
              {activeReview.title}
            </h3>
            <p className="mt-3 text-[14px] leading-[1.8] text-[#5a5a5a] max-w-[420px] my-[11px] mx-0 px-0 text-left">
              {activeReview.body}
            </p>
            <p className="mt-4 text-[16px] text-[#282828]">
              — {activeReview.author}
            </p>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation Controls - centered vertically, moved right, closer together, 40% larger */}
      <div className="absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 flex items-center gap-1" style={{
      marginLeft: '50px'
    }}>
        <button onClick={goPrev} className="w-[67px] h-[67px] flex items-center justify-center hover:opacity-70 transition-opacity" aria-label="Previous review" type="button">
          <img src={arrowLeft} alt="" className="w-[34px] h-[34px]" />
        </button>
        <button onClick={goNext} className="w-[67px] h-[67px] flex items-center justify-center hover:opacity-70 transition-opacity" aria-label="Next review" type="button">
          <img src={arrowRight} alt="" className="w-[34px] h-[34px]" />
        </button>
      </div>
    </section>;
}