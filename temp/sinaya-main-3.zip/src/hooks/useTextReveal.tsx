import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import SplitType from "split-type";

gsap.registerPlugin(ScrollTrigger);

interface TextRevealOptions {
  trigger?: "inView" | "immediate";
  delay?: number;
}

export function useTextReveal<T extends HTMLElement>(options: TextRevealOptions = {}) {
  const { trigger = "inView", delay = 0 } = options;
  const ref = useRef<T>(null);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    // Wait for fonts to load before splitting
    const animate = () => {
      const split = new SplitType(element, { types: "lines,words,chars" });

      const animateLines = () => {
        gsap.from(split.lines, {
          x: "0em",
          y: "1.8em",
          rotate: 0,
          scale: 1,
          opacity: 0,
          filter: "blur(0px)",
          transformOrigin: "50% 0%",
          stagger: 0.03,
          duration: 1.2,
          delay,
          ease: "power4.out",
        });
      };

      if (trigger === "immediate") {
        animateLines();
      } else {
        ScrollTrigger.create({
          trigger: element,
          start: "top 85%",
          once: true,
          onEnter: animateLines,
        });
      }

      return () => {
        split.revert();
        ScrollTrigger.getAll().forEach((st) => st.kill());
      };
    };

    // Small delay to ensure DOM is ready
    const timeoutId = setTimeout(animate, 100);

    return () => {
      clearTimeout(timeoutId);
      ScrollTrigger.getAll().forEach((st) => st.kill());
    };
  }, [trigger, delay]);

  const wrapperStyles: React.CSSProperties = {
    overflow: "visible",
    position: "relative",
  };

  return { ref, wrapperStyles };
}
